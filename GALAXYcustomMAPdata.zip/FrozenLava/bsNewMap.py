# coding=utf-8
import bs
import math
import random
from bsMap import *

class FrozenLava(Map):
    import FrozenLavaLevelDefs as defs
    name = 'FrozenLava'
    playTypes = ['melee','keepAway','teamFlag','kingOfTheHill']

    @classmethod
    def getPreviewTextureName(cls):
        return 'FrozenLavaPreview'

    @classmethod
    def onPreload(cls):
        data = {}
        data['model'] = bs.getModel('FrozenLava')
        data['collideModel'] = bs.getCollideModel('FrozenLavaCollide')
        data['bgTex'] = bs.getTexture('menuBG')
        data['tex'] = bs.getTexture('FrozenLavaColor')
        data['bgModel'] = bs.getModel('thePadBG')
        return data

    def __init__(self):
        Map.__init__(self)
        self.node = bs.newNode('terrain',
                               delegate=self,
                               attrs={'collideModel':self.preloadData['collideModel'],
                                      'model':self.preloadData['model'],
                                      'colorTexture':self.preloadData['tex'],
                                      'materials':[bs.getSharedObject('footingMaterial')]})
        self.foo = bs.newNode('terrain',
                              attrs={'model':self.preloadData['bgModel'],
                                     'lighting':False,
                                     'background':True,
                                     'colorTexture':self.preloadData['bgTex']})
									 

registerMap(FrozenLava)