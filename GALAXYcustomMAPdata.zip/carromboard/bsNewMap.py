# coding=utf-8

from bsMap import *


class carromboard(Map):
    import carromboardDefs as defs
    name = "carromboard"

    playTypes = ['melee', 'football', 'teamFlag', 'keepAway']

    @classmethod
    def getPreviewTextureName(cls):
        return 'carromboardPreview' 

    @classmethod
    def onPreload(cls):
        data = {}
        data['model'] = bs.getModel("carromboard")
        data['collideModel'] = bs.getCollideModel("carromboard")
        data['tex'] = bs.getTexture("carromboard")
        data['bgModel'] = bs.getModel("thePadBG")  
        data['bgTex'] = bs.getTexture("menuBG")
        return data

    def __init__(self):
        Map.__init__(self)
        self.node = bs.newNode('terrain',
                               delegate=self,
                               attrs={'model': self.preloadData['model'],
                                      'collideModel': self.preloadData['collideModel'],
                                      'colorTexture': self.preloadData['tex'],
                                      'materials': [bs.getSharedObject('footingMaterial')]})

        self.bg = bs.NodeActor(bs.newNode('terrain',
                                          attrs={'model': self.preloadData['bgModel'],
                                                 'color': (0.92, 0.91, 0.9),
                                                 'lighting': False,
                                                 'background': True,
                                                 'colorTexture': self.preloadData['bgTex']}))

        self.light = bs.newNode('light',
                                attrs={'position': (2.48, -1.6, -2.4),
                                       'color': (0.2, 0.2, 0.25),
                                       'volumeIntensityScale': 1.0,
                                       'radius': 0.5,
                                       'intensity': 9})


    def _isPointNearEdge(self, p, running=False):
        boxPosition = self.defs.boxes['edgeBox'][0:3]
        boxScale = self.defs.boxes['edgeBox'][6:9]
        x = (p.x() - boxPosition[0]) / boxScale[0]
        z = (p.z() - boxPosition[2]) / boxScale[2]
        return (x < -0.5 or x > 0.5 or z < -0.5 or z > 0.5)


registerMap(carromboard)
